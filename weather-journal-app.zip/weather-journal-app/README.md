# Weather-Journal App Project #

#the use:
The application is used to find out
the weather by entering the zipcode
for a city and you can also add what
you feel.




Great thanks to udacity 

Signature :
Ahmed Mahmoud Abdelfattah