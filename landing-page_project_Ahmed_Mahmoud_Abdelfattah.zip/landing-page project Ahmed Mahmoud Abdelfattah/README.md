
#landing-page project #

*steps of the project
1-I add section4 in intex.Html 
2-I add sourse of app.js in <script> in the bottom of body in intex.html to connet correctly with app.js file 
3-I change content of app.js to make the page dynamic
   #I created four of list <li> in <ul> and creat link<a> in each list<li>
   #I add name of section"textNote" of sections for each link<a>
   #I created DocumentFragment to reduce page load time
   #I created a click event to slide to the section that was clicked
   #I made the section displayed in the screen different to show that it is active

4- I changed some styles in styles.css to suit me.


Great thanks to udacity 

Signature :
Ahmed Mahmoud Abdelfattah